/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiah_teori.pert9;

import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author RECKY
 */
public abstract class Hadiah_teoriPert9 implements ActionListener{

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI() {
        //buat frame
        JFrame frame = new JFrame("Biodata");  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20,30,350,250);
        frame.getContentPane().setLayout(null);
        
        //membuat instance objek aplikasi
        Hadiah_teoriPert9 app = new Hadiah_teoriPert9() {};
        
        //buat tombol nama, nim & alamat
        app.nama = new JButton("Munculkan nama");    
        app.nim = new JButton("Munculkan nim");
        app.alamat = new JButton("Munculkan alamat");
        
        //tambah dan atur ukuran tombol
        frame.getContentPane().add(app.nama);
        app.nama.setBounds(30,20,150,30);
        frame.getContentPane().add(app.nim);
        app.nim.setBounds(30,70,150,30);
        frame.getContentPane().add(app.alamat);
        app.alamat.setBounds(30,120,150,30);
     
        //buat label
        app.label1 = new JLabel("");
        app.label2 = new JLabel("");
        app.label3 = new JLabel("");
        
        //tambah dan atur ukuran label
        app.label1.setBounds(200,25,200,20);
        frame.getContentPane().add(app.label1);
        app.label2.setBounds(200,75,200,20);
        frame.getContentPane().add(app.label2);
        app.label3.setBounds(200,125,200,20);
        frame.getContentPane().add(app.label3);
        
        //mengatur objek aplikasi
        app.nama.addActionListener(app);
        app.nim.addActionListener(app);
        app.alamat.addActionListener(app);
        frame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        //Ini akan dieksekusi ketika button diklik
        if (e.getSource() == nama){
            label1.setText("Ronny Jubhari");   
        }        
        else if (e.getSource() == nim){
            label2.setText("51018019");  
        }   
        else{
            label3.setText("Jl. Maccini Raya");  
        }
    }
        
    public static void main(String[] args) {
        // Memulai Swing GUI
        SwingUtilities.invokeLater(new Runnable(){
            public void run() {
                createAndShowGUI();
            }
        });
    }
    JLabel label1,label2,label3;
    JButton nama,nim,alamat;
}
